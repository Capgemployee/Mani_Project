﻿namespace SE.PL
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supplier));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbAddProd = new System.Windows.Forms.TabPage();
            this.btnSaveSupplier = new System.Windows.Forms.Button();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.cmbCID = new System.Windows.Forms.ComboBox();
            this.txtRanking = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMRP = new System.Windows.Forms.TextBox();
            this.txtUnits = new System.Windows.Forms.TextBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbUpdateProd = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProdName = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboCate = new System.Windows.Forms.ComboBox();
            this.picBoxU = new System.Windows.Forms.PictureBox();
            this.txtProdDesc = new System.Windows.Forms.TextBox();
            this.txtRank = new System.Windows.Forms.TextBox();
            this.txtDisc = new System.Windows.Forms.TextBox();
            this.txtMRPU = new System.Windows.Forms.TextBox();
            this.txtUinP = new System.Windows.Forms.TextBox();
            this.txtUni = new System.Windows.Forms.TextBox();
            this.txtSupID = new System.Windows.Forms.TextBox();
            this.Update = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbDeleteProd = new System.Windows.Forms.TabPage();
            this.lblLogo = new System.Windows.Forms.Label();
            this.linklblLogOut = new System.Windows.Forms.LinkLabel();
            this.lblSID = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label16 = new System.Windows.Forms.Label();
            this.txtPNameDel = new System.Windows.Forms.TextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tbAddProd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.tbUpdateProd.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxU)).BeginInit();
            this.tbDeleteProd.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbAddProd);
            this.tabControl1.Controls.Add(this.tbUpdateProd);
            this.tabControl1.Controls.Add(this.tbDeleteProd);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(197, 50);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(957, 628);
            this.tabControl1.TabIndex = 0;
            // 
            // tbAddProd
            // 
            this.tbAddProd.Controls.Add(this.btnSaveSupplier);
            this.tbAddProd.Controls.Add(this.txtSID);
            this.tbAddProd.Controls.Add(this.txtDesc);
            this.tbAddProd.Controls.Add(this.label10);
            this.tbAddProd.Controls.Add(this.btnUpload);
            this.tbAddProd.Controls.Add(this.picBox);
            this.tbAddProd.Controls.Add(this.txtUnitPrice);
            this.tbAddProd.Controls.Add(this.cmbCID);
            this.tbAddProd.Controls.Add(this.txtRanking);
            this.tbAddProd.Controls.Add(this.txtDiscount);
            this.tbAddProd.Controls.Add(this.label9);
            this.tbAddProd.Controls.Add(this.label8);
            this.tbAddProd.Controls.Add(this.txtMRP);
            this.tbAddProd.Controls.Add(this.txtUnits);
            this.tbAddProd.Controls.Add(this.txtPName);
            this.tbAddProd.Controls.Add(this.label7);
            this.tbAddProd.Controls.Add(this.label6);
            this.tbAddProd.Controls.Add(this.label5);
            this.tbAddProd.Controls.Add(this.label4);
            this.tbAddProd.Controls.Add(this.label3);
            this.tbAddProd.Controls.Add(this.label2);
            this.tbAddProd.ForeColor = System.Drawing.Color.Maroon;
            this.tbAddProd.Location = new System.Drawing.Point(4, 30);
            this.tbAddProd.Name = "tbAddProd";
            this.tbAddProd.Padding = new System.Windows.Forms.Padding(3);
            this.tbAddProd.Size = new System.Drawing.Size(949, 594);
            this.tbAddProd.TabIndex = 0;
            this.tbAddProd.Text = "Add Product";
            this.tbAddProd.UseVisualStyleBackColor = true;
            // 
            // btnSaveSupplier
            // 
            this.btnSaveSupplier.AllowDrop = true;
            this.btnSaveSupplier.Location = new System.Drawing.Point(353, 528);
            this.btnSaveSupplier.Name = "btnSaveSupplier";
            this.btnSaveSupplier.Size = new System.Drawing.Size(225, 29);
            this.btnSaveSupplier.TabIndex = 43;
            this.btnSaveSupplier.Text = "Save ";
            this.btnSaveSupplier.UseVisualStyleBackColor = true;
            this.btnSaveSupplier.Click += new System.EventHandler(this.btnSaveSupplier_Click);
            // 
            // txtSID
            // 
            this.txtSID.Enabled = false;
            this.txtSID.Location = new System.Drawing.Point(202, 92);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(223, 29);
            this.txtSID.TabIndex = 42;
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(702, 32);
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDesc.Size = new System.Drawing.Size(223, 160);
            this.txtDesc.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(487, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 21);
            this.label10.TabIndex = 40;
            this.label10.Text = "Product Description";
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(491, 409);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(144, 31);
            this.btnUpload.TabIndex = 39;
            this.btnUpload.Text = "Upload Image";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // picBox
            // 
            this.picBox.Location = new System.Drawing.Point(491, 229);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(372, 162);
            this.picBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox.TabIndex = 38;
            this.picBox.TabStop = false;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Location = new System.Drawing.Point(202, 263);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(223, 29);
            this.txtUnitPrice.TabIndex = 36;
            // 
            // cmbCID
            // 
            this.cmbCID.FormattingEnabled = true;
            this.cmbCID.Location = new System.Drawing.Point(202, 151);
            this.cmbCID.Name = "cmbCID";
            this.cmbCID.Size = new System.Drawing.Size(223, 29);
            this.cmbCID.TabIndex = 35;
            // 
            // txtRanking
            // 
            this.txtRanking.Location = new System.Drawing.Point(202, 453);
            this.txtRanking.Name = "txtRanking";
            this.txtRanking.Size = new System.Drawing.Size(223, 29);
            this.txtRanking.TabIndex = 33;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Location = new System.Drawing.Point(202, 393);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(223, 29);
            this.txtDiscount.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 461);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 21);
            this.label9.TabIndex = 30;
            this.label9.Text = "Ranking";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 21);
            this.label8.TabIndex = 29;
            this.label8.Text = "Discount";
            // 
            // txtMRP
            // 
            this.txtMRP.Location = new System.Drawing.Point(202, 328);
            this.txtMRP.Name = "txtMRP";
            this.txtMRP.Size = new System.Drawing.Size(223, 29);
            this.txtMRP.TabIndex = 28;
            // 
            // txtUnits
            // 
            this.txtUnits.Location = new System.Drawing.Point(202, 213);
            this.txtUnits.Name = "txtUnits";
            this.txtUnits.Size = new System.Drawing.Size(223, 29);
            this.txtUnits.TabIndex = 26;
            // 
            // txtPName
            // 
            this.txtPName.Location = new System.Drawing.Point(202, 40);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(223, 29);
            this.txtPName.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 21);
            this.label7.TabIndex = 21;
            this.label7.Text = "MRP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 21);
            this.label6.TabIndex = 20;
            this.label6.Text = "Unit Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 21);
            this.label5.TabIndex = 19;
            this.label5.Text = "Units";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 21);
            this.label4.TabIndex = 18;
            this.label4.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 21);
            this.label3.TabIndex = 17;
            this.label3.Text = "Supplier ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 21);
            this.label2.TabIndex = 16;
            this.label2.Text = "Product Name";
            // 
            // tbUpdateProd
            // 
            this.tbUpdateProd.Controls.Add(this.label1);
            this.tbUpdateProd.Controls.Add(this.txtProdName);
            this.tbUpdateProd.Controls.Add(this.panel1);
            this.tbUpdateProd.ForeColor = System.Drawing.Color.Maroon;
            this.tbUpdateProd.Location = new System.Drawing.Point(4, 30);
            this.tbUpdateProd.Name = "tbUpdateProd";
            this.tbUpdateProd.Padding = new System.Windows.Forms.Padding(3);
            this.tbUpdateProd.Size = new System.Drawing.Size(949, 594);
            this.tbUpdateProd.TabIndex = 1;
            this.tbUpdateProd.Text = "Update Product";
            this.tbUpdateProd.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "Product Name";
            // 
            // txtProdName
            // 
            this.txtProdName.Location = new System.Drawing.Point(181, 39);
            this.txtProdName.Name = "txtProdName";
            this.txtProdName.Size = new System.Drawing.Size(213, 29);
            this.txtProdName.TabIndex = 1;
            this.txtProdName.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.txtProdName_PreviewKeyDown);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboCate);
            this.panel1.Controls.Add(this.picBoxU);
            this.panel1.Controls.Add(this.txtProdDesc);
            this.panel1.Controls.Add(this.txtRank);
            this.panel1.Controls.Add(this.txtDisc);
            this.panel1.Controls.Add(this.txtMRPU);
            this.panel1.Controls.Add(this.txtUinP);
            this.panel1.Controls.Add(this.txtUni);
            this.panel1.Controls.Add(this.txtSupID);
            this.panel1.Controls.Add(this.Update);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.lbl5);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(25, 92);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(892, 455);
            this.panel1.TabIndex = 0;
            // 
            // comboCate
            // 
            this.comboCate.FormattingEnabled = true;
            this.comboCate.Location = new System.Drawing.Point(156, 92);
            this.comboCate.Name = "comboCate";
            this.comboCate.Size = new System.Drawing.Size(213, 29);
            this.comboCate.TabIndex = 17;
            // 
            // picBoxU
            // 
            this.picBoxU.Location = new System.Drawing.Point(470, 187);
            this.picBoxU.Name = "picBoxU";
            this.picBoxU.Size = new System.Drawing.Size(377, 183);
            this.picBoxU.TabIndex = 16;
            this.picBoxU.TabStop = false;
            // 
            // txtProdDesc
            // 
            this.txtProdDesc.Location = new System.Drawing.Point(605, 27);
            this.txtProdDesc.Multiline = true;
            this.txtProdDesc.Name = "txtProdDesc";
            this.txtProdDesc.Size = new System.Drawing.Size(242, 119);
            this.txtProdDesc.TabIndex = 15;
            // 
            // txtRank
            // 
            this.txtRank.Location = new System.Drawing.Point(156, 384);
            this.txtRank.Name = "txtRank";
            this.txtRank.Size = new System.Drawing.Size(213, 29);
            this.txtRank.TabIndex = 14;
            // 
            // txtDisc
            // 
            this.txtDisc.Location = new System.Drawing.Point(156, 323);
            this.txtDisc.Name = "txtDisc";
            this.txtDisc.Size = new System.Drawing.Size(213, 29);
            this.txtDisc.TabIndex = 13;
            // 
            // txtMRPU
            // 
            this.txtMRPU.Location = new System.Drawing.Point(156, 265);
            this.txtMRPU.Name = "txtMRPU";
            this.txtMRPU.Size = new System.Drawing.Size(213, 29);
            this.txtMRPU.TabIndex = 12;
            // 
            // txtUinP
            // 
            this.txtUinP.Location = new System.Drawing.Point(156, 207);
            this.txtUinP.Name = "txtUinP";
            this.txtUinP.Size = new System.Drawing.Size(213, 29);
            this.txtUinP.TabIndex = 11;
            // 
            // txtUni
            // 
            this.txtUni.Location = new System.Drawing.Point(156, 146);
            this.txtUni.Name = "txtUni";
            this.txtUni.Size = new System.Drawing.Size(213, 29);
            this.txtUni.TabIndex = 10;
            // 
            // txtSupID
            // 
            this.txtSupID.Location = new System.Drawing.Point(156, 27);
            this.txtSupID.Name = "txtSupID";
            this.txtSupID.Size = new System.Drawing.Size(213, 29);
            this.txtSupID.TabIndex = 9;
            // 
            // Update
            // 
            this.Update.Location = new System.Drawing.Point(740, 392);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(98, 28);
            this.Update.TabIndex = 8;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(422, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(161, 21);
            this.label18.TabIndex = 7;
            this.label18.Text = "Product Description";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 392);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 21);
            this.label17.TabIndex = 6;
            this.label17.Text = "Ranking";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(18, 323);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(77, 21);
            this.lbl5.TabIndex = 5;
            this.lbl5.Text = "Discount";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 268);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 21);
            this.label15.TabIndex = 4;
            this.label15.Text = "MRP";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 207);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 21);
            this.label14.TabIndex = 3;
            this.label14.Text = "Unit Price";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 146);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 21);
            this.label13.TabIndex = 2;
            this.label13.Text = "Units";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 21);
            this.label12.TabIndex = 1;
            this.label12.Text = "Category";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 21);
            this.label11.TabIndex = 0;
            this.label11.Text = "Supplier ID";
            // 
            // tbDeleteProd
            // 
            this.tbDeleteProd.Controls.Add(this.Delete);
            this.tbDeleteProd.Controls.Add(this.txtPNameDel);
            this.tbDeleteProd.Controls.Add(this.label16);
            this.tbDeleteProd.ForeColor = System.Drawing.Color.Maroon;
            this.tbDeleteProd.Location = new System.Drawing.Point(4, 30);
            this.tbDeleteProd.Name = "tbDeleteProd";
            this.tbDeleteProd.Size = new System.Drawing.Size(949, 594);
            this.tbDeleteProd.TabIndex = 2;
            this.tbDeleteProd.Text = "Delete Product";
            this.tbDeleteProd.UseVisualStyleBackColor = true;
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.BackColor = System.Drawing.Color.Transparent;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.Location = new System.Drawing.Point(54, 50);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(120, 29);
            this.lblLogo.TabIndex = 3;
            this.lblLogo.Text = "Shopeasy";
            // 
            // linklblLogOut
            // 
            this.linklblLogOut.AutoSize = true;
            this.linklblLogOut.BackColor = System.Drawing.Color.Silver;
            this.linklblLogOut.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblLogOut.LinkColor = System.Drawing.Color.Maroon;
            this.linklblLogOut.Location = new System.Drawing.Point(1082, 26);
            this.linklblLogOut.Name = "linklblLogOut";
            this.linklblLogOut.Size = new System.Drawing.Size(68, 21);
            this.linklblLogOut.TabIndex = 6;
            this.linklblLogOut.TabStop = true;
            this.linklblLogOut.Text = "LogOut";
            this.linklblLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblLogOut_LinkClicked);
            // 
            // lblSID
            // 
            this.lblSID.AutoSize = true;
            this.lblSID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSID.Location = new System.Drawing.Point(997, 26);
            this.lblSID.Name = "lblSID";
            this.lblSID.Size = new System.Drawing.Size(0, 20);
            this.lblSID.TabIndex = 7;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(45, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 21);
            this.label16.TabIndex = 0;
            this.label16.Text = "Product Name";
            // 
            // txtPNameDel
            // 
            this.txtPNameDel.Location = new System.Drawing.Point(169, 67);
            this.txtPNameDel.Name = "txtPNameDel";
            this.txtPNameDel.Size = new System.Drawing.Size(206, 29);
            this.txtPNameDel.TabIndex = 1;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(395, 66);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(112, 29);
            this.Delete.TabIndex = 2;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.lblSID);
            this.Controls.Add(this.linklblLogOut);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.tabControl1);
            this.ForeColor = System.Drawing.Color.Salmon;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Supplier";
            this.Text = "Supplier";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Supplier_Activated);
            this.Load += new System.EventHandler(this.Supplier_Load);
            this.tabControl1.ResumeLayout(false);
            this.tbAddProd.ResumeLayout(false);
            this.tbAddProd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.tbUpdateProd.ResumeLayout(false);
            this.tbUpdateProd.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxU)).EndInit();
            this.tbDeleteProd.ResumeLayout(false);
            this.tbDeleteProd.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbAddProd;
        private System.Windows.Forms.TabPage tbUpdateProd;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.TabPage tbDeleteProd;
        private System.Windows.Forms.TextBox txtMRP;
        private System.Windows.Forms.TextBox txtUnits;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.ComboBox cmbCID;
        private System.Windows.Forms.TextBox txtRanking;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSaveSupplier;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.LinkLabel linklblLogOut;
        private System.Windows.Forms.Label lblSID;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProdName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtUni;
        private System.Windows.Forms.TextBox txtSupID;
        private System.Windows.Forms.TextBox txtMRPU;
        private System.Windows.Forms.TextBox txtUinP;
        private System.Windows.Forms.TextBox txtRank;
        private System.Windows.Forms.TextBox txtDisc;
        private System.Windows.Forms.PictureBox picBoxU;
        private System.Windows.Forms.TextBox txtProdDesc;
        private System.Windows.Forms.ComboBox comboCate;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.TextBox txtPNameDel;
        private System.Windows.Forms.Label label16;
    }
}
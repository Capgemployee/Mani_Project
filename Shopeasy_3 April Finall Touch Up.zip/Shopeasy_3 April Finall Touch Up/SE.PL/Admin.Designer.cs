﻿namespace SE.PL
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.tbCtrlAdmin = new System.Windows.Forms.TabControl();
            this.tbAddSupplier = new System.Windows.Forms.TabPage();
            this.btnAddSupplier = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtCPassword = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtRank = new System.Windows.Forms.TextBox();
            this.txtWeb = new System.Windows.Forms.TextBox();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.txtMobNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtPincode = new System.Windows.Forms.TextBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtCNAme = new System.Windows.Forms.TextBox();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbViewSuppliers = new System.Windows.Forms.TabPage();
            this.btnViewSuppliers = new System.Windows.Forms.Button();
            this.grdViewSuppliers = new System.Windows.Forms.DataGridView();
            this.tbViewOrders = new System.Windows.Forms.TabPage();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.grdViewOrders = new System.Windows.Forms.DataGridView();
            this.tbViewCustomers = new System.Windows.Forms.TabPage();
            this.btnViewCustomers = new System.Windows.Forms.Button();
            this.grdViewCustomers = new System.Windows.Forms.DataGridView();
            this.tbViewProducts = new System.Windows.Forms.TabPage();
            this.btnViewProducts = new System.Windows.Forms.Button();
            this.grdViewProducts = new System.Windows.Forms.DataGridView();
            this.lblLogo = new System.Windows.Forms.Label();
            this.linklblLogOut = new System.Windows.Forms.LinkLabel();
            this.tbCtrlAdmin.SuspendLayout();
            this.tbAddSupplier.SuspendLayout();
            this.tbViewSuppliers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdViewSuppliers)).BeginInit();
            this.tbViewOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdViewOrders)).BeginInit();
            this.tbViewCustomers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdViewCustomers)).BeginInit();
            this.tbViewProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdViewProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // tbCtrlAdmin
            // 
            this.tbCtrlAdmin.Controls.Add(this.tbAddSupplier);
            this.tbCtrlAdmin.Controls.Add(this.tbViewSuppliers);
            this.tbCtrlAdmin.Controls.Add(this.tbViewOrders);
            this.tbCtrlAdmin.Controls.Add(this.tbViewCustomers);
            this.tbCtrlAdmin.Controls.Add(this.tbViewProducts);
            this.tbCtrlAdmin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCtrlAdmin.Location = new System.Drawing.Point(149, 73);
            this.tbCtrlAdmin.Name = "tbCtrlAdmin";
            this.tbCtrlAdmin.SelectedIndex = 0;
            this.tbCtrlAdmin.Size = new System.Drawing.Size(957, 628);
            this.tbCtrlAdmin.TabIndex = 0;
            // 
            // tbAddSupplier
            // 
            this.tbAddSupplier.Controls.Add(this.btnAddSupplier);
            this.tbAddSupplier.Controls.Add(this.txtPassword);
            this.tbAddSupplier.Controls.Add(this.txtCPassword);
            this.tbAddSupplier.Controls.Add(this.txtNote);
            this.tbAddSupplier.Controls.Add(this.txtRank);
            this.tbAddSupplier.Controls.Add(this.txtWeb);
            this.tbAddSupplier.Controls.Add(this.txtEmailID);
            this.tbAddSupplier.Controls.Add(this.txtMobNo);
            this.tbAddSupplier.Controls.Add(this.label8);
            this.tbAddSupplier.Controls.Add(this.label9);
            this.tbAddSupplier.Controls.Add(this.label10);
            this.tbAddSupplier.Controls.Add(this.label11);
            this.tbAddSupplier.Controls.Add(this.label12);
            this.tbAddSupplier.Controls.Add(this.label13);
            this.tbAddSupplier.Controls.Add(this.label14);
            this.tbAddSupplier.Controls.Add(this.txtPincode);
            this.tbAddSupplier.Controls.Add(this.cmbState);
            this.tbAddSupplier.Controls.Add(this.txtCity);
            this.tbAddSupplier.Controls.Add(this.txtAddress2);
            this.tbAddSupplier.Controls.Add(this.txtAddress1);
            this.tbAddSupplier.Controls.Add(this.txtCNAme);
            this.tbAddSupplier.Controls.Add(this.txtSID);
            this.tbAddSupplier.Controls.Add(this.label7);
            this.tbAddSupplier.Controls.Add(this.label6);
            this.tbAddSupplier.Controls.Add(this.label5);
            this.tbAddSupplier.Controls.Add(this.label4);
            this.tbAddSupplier.Controls.Add(this.label3);
            this.tbAddSupplier.Controls.Add(this.label2);
            this.tbAddSupplier.Controls.Add(this.label1);
            this.tbAddSupplier.ForeColor = System.Drawing.Color.Maroon;
            this.tbAddSupplier.Location = new System.Drawing.Point(4, 30);
            this.tbAddSupplier.Name = "tbAddSupplier";
            this.tbAddSupplier.Padding = new System.Windows.Forms.Padding(3);
            this.tbAddSupplier.Size = new System.Drawing.Size(949, 594);
            this.tbAddSupplier.TabIndex = 0;
            this.tbAddSupplier.Text = "Add Supplier";
            this.tbAddSupplier.UseVisualStyleBackColor = true;
            // 
            // btnAddSupplier
            // 
            this.btnAddSupplier.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSupplier.Location = new System.Drawing.Point(387, 506);
            this.btnAddSupplier.Name = "btnAddSupplier";
            this.btnAddSupplier.Size = new System.Drawing.Size(165, 34);
            this.btnAddSupplier.TabIndex = 30;
            this.btnAddSupplier.Text = "Add Supplier";
            this.btnAddSupplier.UseVisualStyleBackColor = true;
            this.btnAddSupplier.Click += new System.EventHandler(this.btnAddSupplier_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(691, 363);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(223, 29);
            this.txtPassword.TabIndex = 29;
            // 
            // txtCPassword
            // 
            this.txtCPassword.Location = new System.Drawing.Point(691, 424);
            this.txtCPassword.Name = "txtCPassword";
            this.txtCPassword.PasswordChar = '*';
            this.txtCPassword.Size = new System.Drawing.Size(223, 29);
            this.txtCPassword.TabIndex = 28;
            this.txtCPassword.Leave += new System.EventHandler(this.txtCPassword_Leave);
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(691, 304);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(223, 29);
            this.txtNote.TabIndex = 26;
            // 
            // txtRank
            // 
            this.txtRank.Location = new System.Drawing.Point(691, 251);
            this.txtRank.Name = "txtRank";
            this.txtRank.Size = new System.Drawing.Size(223, 29);
            this.txtRank.TabIndex = 25;
            // 
            // txtWeb
            // 
            this.txtWeb.Location = new System.Drawing.Point(691, 198);
            this.txtWeb.Name = "txtWeb";
            this.txtWeb.Size = new System.Drawing.Size(223, 29);
            this.txtWeb.TabIndex = 24;
            // 
            // txtEmailID
            // 
            this.txtEmailID.Location = new System.Drawing.Point(691, 146);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(223, 29);
            this.txtEmailID.TabIndex = 23;
            // 
            // txtMobNo
            // 
            this.txtMobNo.Location = new System.Drawing.Point(691, 89);
            this.txtMobNo.Name = "txtMobNo";
            this.txtMobNo.Size = new System.Drawing.Size(223, 29);
            this.txtMobNo.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(518, 432);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 21);
            this.label8.TabIndex = 21;
            this.label8.Text = "Confirm Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(518, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 21);
            this.label9.TabIndex = 20;
            this.label9.Text = "Password";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(518, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 21);
            this.label10.TabIndex = 19;
            this.label10.Text = "Note";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(518, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 21);
            this.label11.TabIndex = 18;
            this.label11.Text = "Ranking";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(518, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 21);
            this.label12.TabIndex = 17;
            this.label12.Text = "Website";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(518, 154);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 21);
            this.label13.TabIndex = 16;
            this.label13.Text = "Email ID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(518, 97);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 21);
            this.label14.TabIndex = 15;
            this.label14.Text = "Mobile Number";
            // 
            // txtPincode
            // 
            this.txtPincode.Location = new System.Drawing.Point(209, 429);
            this.txtPincode.Name = "txtPincode";
            this.txtPincode.Size = new System.Drawing.Size(223, 29);
            this.txtPincode.TabIndex = 14;
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Items.AddRange(new object[] {
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu & Kashmir",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura ",
            "Uttar Pradesh",
            "West Bengal ",
            "Chhattisgarh",
            "Uttarakhand",
            "Jharkhand",
            "Telangana"});
            this.cmbState.Location = new System.Drawing.Point(209, 368);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(223, 29);
            this.cmbState.TabIndex = 13;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(209, 309);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(223, 29);
            this.txtCity.TabIndex = 12;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(209, 256);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(223, 29);
            this.txtAddress2.TabIndex = 11;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(209, 203);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(223, 29);
            this.txtAddress1.TabIndex = 10;
            // 
            // txtCNAme
            // 
            this.txtCNAme.Location = new System.Drawing.Point(209, 151);
            this.txtCNAme.Name = "txtCNAme";
            this.txtCNAme.Size = new System.Drawing.Size(223, 29);
            this.txtCNAme.TabIndex = 9;
            // 
            // txtSID
            // 
            this.txtSID.Enabled = false;
            this.txtSID.Location = new System.Drawing.Point(209, 94);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(223, 29);
            this.txtSID.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 437);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 21);
            this.label7.TabIndex = 6;
            this.label7.Text = "Pincode";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "State";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "City";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Supplier ID";
            // 
            // tbViewSuppliers
            // 
            this.tbViewSuppliers.Controls.Add(this.btnViewSuppliers);
            this.tbViewSuppliers.Controls.Add(this.grdViewSuppliers);
            this.tbViewSuppliers.ForeColor = System.Drawing.Color.Maroon;
            this.tbViewSuppliers.Location = new System.Drawing.Point(4, 30);
            this.tbViewSuppliers.Name = "tbViewSuppliers";
            this.tbViewSuppliers.Padding = new System.Windows.Forms.Padding(3);
            this.tbViewSuppliers.Size = new System.Drawing.Size(949, 594);
            this.tbViewSuppliers.TabIndex = 1;
            this.tbViewSuppliers.Text = "View Suppliers";
            this.tbViewSuppliers.UseVisualStyleBackColor = true;
            // 
            // btnViewSuppliers
            // 
            this.btnViewSuppliers.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewSuppliers.Location = new System.Drawing.Point(387, 506);
            this.btnViewSuppliers.Name = "btnViewSuppliers";
            this.btnViewSuppliers.Size = new System.Drawing.Size(93, 30);
            this.btnViewSuppliers.TabIndex = 1;
            this.btnViewSuppliers.Text = "View ";
            this.btnViewSuppliers.UseVisualStyleBackColor = true;
            this.btnViewSuppliers.Click += new System.EventHandler(this.btnViewSuppliers_Click);
            // 
            // grdViewSuppliers
            // 
            this.grdViewSuppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdViewSuppliers.Location = new System.Drawing.Point(31, 38);
            this.grdViewSuppliers.Name = "grdViewSuppliers";
            this.grdViewSuppliers.Size = new System.Drawing.Size(884, 420);
            this.grdViewSuppliers.TabIndex = 0;
            // 
            // tbViewOrders
            // 
            this.tbViewOrders.Controls.Add(this.btnViewOrders);
            this.tbViewOrders.Controls.Add(this.grdViewOrders);
            this.tbViewOrders.ForeColor = System.Drawing.Color.Maroon;
            this.tbViewOrders.Location = new System.Drawing.Point(4, 30);
            this.tbViewOrders.Name = "tbViewOrders";
            this.tbViewOrders.Size = new System.Drawing.Size(949, 594);
            this.tbViewOrders.TabIndex = 2;
            this.tbViewOrders.Text = "View Orders";
            this.tbViewOrders.UseVisualStyleBackColor = true;
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(387, 506);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(93, 30);
            this.btnViewOrders.TabIndex = 2;
            this.btnViewOrders.Text = "View";
            this.btnViewOrders.UseVisualStyleBackColor = true;
            this.btnViewOrders.Click += new System.EventHandler(this.btnViewOrders_Click);
            // 
            // grdViewOrders
            // 
            this.grdViewOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdViewOrders.Location = new System.Drawing.Point(31, 38);
            this.grdViewOrders.Name = "grdViewOrders";
            this.grdViewOrders.Size = new System.Drawing.Size(884, 420);
            this.grdViewOrders.TabIndex = 1;
            // 
            // tbViewCustomers
            // 
            this.tbViewCustomers.Controls.Add(this.btnViewCustomers);
            this.tbViewCustomers.Controls.Add(this.grdViewCustomers);
            this.tbViewCustomers.ForeColor = System.Drawing.Color.Maroon;
            this.tbViewCustomers.Location = new System.Drawing.Point(4, 30);
            this.tbViewCustomers.Name = "tbViewCustomers";
            this.tbViewCustomers.Size = new System.Drawing.Size(949, 594);
            this.tbViewCustomers.TabIndex = 3;
            this.tbViewCustomers.Text = "View Customers";
            this.tbViewCustomers.UseVisualStyleBackColor = true;
            // 
            // btnViewCustomers
            // 
            this.btnViewCustomers.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCustomers.Location = new System.Drawing.Point(387, 506);
            this.btnViewCustomers.Name = "btnViewCustomers";
            this.btnViewCustomers.Size = new System.Drawing.Size(93, 30);
            this.btnViewCustomers.TabIndex = 2;
            this.btnViewCustomers.Text = "View ";
            this.btnViewCustomers.UseVisualStyleBackColor = true;
            this.btnViewCustomers.Click += new System.EventHandler(this.btnViewCustomers_Click);
            // 
            // grdViewCustomers
            // 
            this.grdViewCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdViewCustomers.Location = new System.Drawing.Point(31, 38);
            this.grdViewCustomers.Name = "grdViewCustomers";
            this.grdViewCustomers.Size = new System.Drawing.Size(884, 420);
            this.grdViewCustomers.TabIndex = 1;
            // 
            // tbViewProducts
            // 
            this.tbViewProducts.Controls.Add(this.btnViewProducts);
            this.tbViewProducts.Controls.Add(this.grdViewProducts);
            this.tbViewProducts.ForeColor = System.Drawing.Color.Maroon;
            this.tbViewProducts.Location = new System.Drawing.Point(4, 30);
            this.tbViewProducts.Name = "tbViewProducts";
            this.tbViewProducts.Size = new System.Drawing.Size(949, 594);
            this.tbViewProducts.TabIndex = 4;
            this.tbViewProducts.Text = "View Products";
            this.tbViewProducts.UseVisualStyleBackColor = true;
            // 
            // btnViewProducts
            // 
            this.btnViewProducts.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewProducts.Location = new System.Drawing.Point(388, 516);
            this.btnViewProducts.Name = "btnViewProducts";
            this.btnViewProducts.Size = new System.Drawing.Size(93, 30);
            this.btnViewProducts.TabIndex = 4;
            this.btnViewProducts.Text = "View ";
            this.btnViewProducts.UseVisualStyleBackColor = true;
            this.btnViewProducts.Click += new System.EventHandler(this.btnViewProducts_Click);
            // 
            // grdViewProducts
            // 
            this.grdViewProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdViewProducts.Location = new System.Drawing.Point(32, 48);
            this.grdViewProducts.Name = "grdViewProducts";
            this.grdViewProducts.Size = new System.Drawing.Size(884, 420);
            this.grdViewProducts.TabIndex = 3;
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.BackColor = System.Drawing.Color.Transparent;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.Location = new System.Drawing.Point(23, 73);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(120, 29);
            this.lblLogo.TabIndex = 3;
            this.lblLogo.Text = "Shopeasy";
            // 
            // linklblLogOut
            // 
            this.linklblLogOut.AutoSize = true;
            this.linklblLogOut.BackColor = System.Drawing.Color.Silver;
            this.linklblLogOut.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblLogOut.ForeColor = System.Drawing.Color.Maroon;
            this.linklblLogOut.LinkColor = System.Drawing.Color.Maroon;
            this.linklblLogOut.Location = new System.Drawing.Point(1038, 23);
            this.linklblLogOut.Name = "linklblLogOut";
            this.linklblLogOut.Size = new System.Drawing.Size(68, 21);
            this.linklblLogOut.TabIndex = 4;
            this.linklblLogOut.TabStop = true;
            this.linklblLogOut.Text = "LogOut";
            this.linklblLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinklblLogOut_LinkClicked);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.linklblLogOut);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.tbCtrlAdmin);
            this.ForeColor = System.Drawing.Color.Salmon;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.Text = "Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_Load);
            this.tbCtrlAdmin.ResumeLayout(false);
            this.tbAddSupplier.ResumeLayout(false);
            this.tbAddSupplier.PerformLayout();
            this.tbViewSuppliers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdViewSuppliers)).EndInit();
            this.tbViewOrders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdViewOrders)).EndInit();
            this.tbViewCustomers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdViewCustomers)).EndInit();
            this.tbViewProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdViewProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbCtrlAdmin;
        private System.Windows.Forms.TabPage tbAddSupplier;
        private System.Windows.Forms.TabPage tbViewSuppliers;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.TabPage tbViewOrders;
        private System.Windows.Forms.DataGridView grdViewSuppliers;
        private System.Windows.Forms.DataGridView grdViewOrders;
        private System.Windows.Forms.TabPage tbViewCustomers;
        private System.Windows.Forms.DataGridView grdViewCustomers;
        private System.Windows.Forms.Button btnViewSuppliers;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnViewCustomers;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtCNAme;
        private System.Windows.Forms.TextBox txtCPassword;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtWeb;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.TextBox txtMobNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtPincode;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.TextBox txtRank;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.LinkLabel linklblLogOut;
        private System.Windows.Forms.Button btnAddSupplier;
        private System.Windows.Forms.TabPage tbViewProducts;
        private System.Windows.Forms.Button btnViewProducts;
        private System.Windows.Forms.DataGridView grdViewProducts;
    }
}
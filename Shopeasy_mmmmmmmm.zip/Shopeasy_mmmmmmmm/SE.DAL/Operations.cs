﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    public class Operations
    {
        SqlConnection con;
        SqlCommand cmd;
        DataTable table;
        SqlDataReader dr;

        public Operations()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ShopEasy"].ConnectionString);
        }

        public bool AddSupplier(Supplier sup)
        {
            bool SupplierAdded = false;
            try
            {
                cmd = new SqlCommand("EC.insertSupplier", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Sid", sup.SupplierID);
                cmd.Parameters.AddWithValue("@Cname", sup.CompanyName);
                cmd.Parameters.AddWithValue("@Address1", sup.Address1);
                cmd.Parameters.AddWithValue("@Address2", sup.Address2);
                cmd.Parameters.AddWithValue("@City", sup.City);
                cmd.Parameters.AddWithValue("@State", sup.State);
                cmd.Parameters.AddWithValue("@PinCode", sup.PostalCode);
                cmd.Parameters.AddWithValue("@Mobile", sup.MobileNo);
                cmd.Parameters.AddWithValue("@Email", sup.EmailId);
                cmd.Parameters.AddWithValue("@Web", sup.Website);
                cmd.Parameters.AddWithValue("@Rank", sup.Ranking);
                cmd.Parameters.AddWithValue("@Note", sup.Note);
                cmd.Parameters.AddWithValue("@Pass", sup.Password);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    SupplierAdded = true;
                }

            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return SupplierAdded;
        }
        public int supplierID()
        {
            int SupplierID = 0;
            try
            {
                table = new DataTable();
                cmd = new SqlCommand("EC.getSupplierID", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                DataSet ds = new DataSet();
                ds.Tables.Add(table);
                SupplierID = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
                SupplierID++;
            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return SupplierID;

        }
        public bool authSupplier(int SID, string pass)
        {
            bool SupplierAuth = false;
            try
            {
                cmd = new SqlCommand("[EC].[authenticateSupplier]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SID", SID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    SupplierAuth = true;
                }
            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return SupplierAuth;
        }
        public DataTable getCategory()
        {
            table = new DataTable();
            try
            {

                cmd = new SqlCommand("[EC].[getCategory]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return table;
        }
        public bool addProduct(Product prd)
        {
            bool productAdded = false;
            try
            {
                cmd = new SqlCommand("EC.addProduct", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PName", prd.ProductName);
                cmd.Parameters.AddWithValue("@SID", prd.SupplierID);
                cmd.Parameters.AddWithValue("@CID", prd.CategoryID);
                cmd.Parameters.AddWithValue("@Units", prd.Units);
                cmd.Parameters.AddWithValue("@UPrice", prd.UnitPrice);
                cmd.Parameters.AddWithValue("@MRP", prd.MRP);
                cmd.Parameters.AddWithValue("@Discount", prd.Discount);
                cmd.Parameters.AddWithValue("@Picture", prd.Picture);
                cmd.Parameters.AddWithValue("@Rank", prd.Ranking);
                cmd.Parameters.AddWithValue("@PDesc", prd.ProductDesc);
                cmd.Parameters.AddWithValue("@DOM", prd.DOM);
                cmd.Parameters.AddWithValue("@CDesc", prd.CategorygDesc);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productAdded = true;
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return productAdded;
        }
        public DataTable viewProduct()
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("EC.viewProducts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return table;
        }
        public DataTable viewCustomer()
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("EC.viewCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return table;
        }
        public DataTable viewOrder()
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("EC.viewOrder", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return table;
        }
        public DataTable viewSupplier()
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("EC.viewSupplier", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return table;
        }
        public bool addCustomer(Customer cust)
        {
            bool customerAdded = false;
            try
            {
                cmd = new SqlCommand("[EC].[addCustomer]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CFName", cust.CFName);
                cmd.Parameters.AddWithValue("@CLName", cust.CLName);
                cmd.Parameters.AddWithValue("@Email", cust.Email);
                cmd.Parameters.AddWithValue("@Mobile", cust.Mobile);
                cmd.Parameters.AddWithValue("@UID", cust.UserID);
                cmd.Parameters.AddWithValue("@Pass", cust.Pass);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    customerAdded = true;
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return customerAdded;
        }
        public DataTable searchCustomer(string CID, string pass)
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("[EC].[authenticateCustomer]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UID", CID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);

            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return table;
        }
        public bool addOrder(Order ord)
        {
            bool orderAdded = false;
            try
            {
                cmd = new SqlCommand("[EC].[addOrder]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ODate", ord.ODate);
                cmd.Parameters.AddWithValue("@CID", ord.CustomerID);
                cmd.Parameters.AddWithValue("@PID", ord.ProductID);
                cmd.Parameters.AddWithValue("@Price", ord.Price);
                cmd.Parameters.AddWithValue("@Quantity", ord.Quantity);
                cmd.Parameters.AddWithValue("@Total", ord.Total);
                cmd.Parameters.AddWithValue("@BARNo", ord.BARoomNo);
                cmd.Parameters.AddWithValue("@BACity", ord.BACity);
                cmd.Parameters.AddWithValue("@BAState", ord.BAState);
                cmd.Parameters.AddWithValue("@BAPincode", ord.BAPincode);
                cmd.Parameters.AddWithValue("@SARNo", ord.SARoomNo);
                cmd.Parameters.AddWithValue("@SACity", ord.SACity);
                cmd.Parameters.AddWithValue("@SAState", ord.SAState);
                cmd.Parameters.AddWithValue("@SPincode", ord.SAPincode);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    orderAdded = true;
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return orderAdded;
        }
        public DataTable searchCategory(string type)
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("[EC].[searchCategory]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Type", type);
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);

            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return table;
        }
        public DataTable searchProduct(string type,string type1)
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("[EC].[searchProduct]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Type", type);
                cmd.Parameters.AddWithValue("@Type1", type1);
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);

            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return table;
        }
        public DataTable getProductByName(string type)
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("[EC].[getProductByName]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Type", type);
                con.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);

            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            finally
            {

                con.Close();
            }
            return table;
        }
    }
}

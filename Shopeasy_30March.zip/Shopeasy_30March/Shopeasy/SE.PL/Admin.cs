﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.BL;

namespace SE.PL
{
    public partial class Admin : Form
    {
        
        
       
        public Admin()
        {
            InitializeComponent();
        }
        public bool isNumber;
        public int result;
        public void clearAll()
        {
            txtAddress1.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            
        }
        CustomValidation cv = new CustomValidation();
        private void LinklblLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            this.Hide();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            
            try
            { 
                txtSID.Text = cv.supplierID().ToString();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnAddSupplier_Click(object sender, EventArgs e)
        { 
            SE.Entity.Supplier sp = new Entity.Supplier();

            sp.SupplierID = Convert.ToInt32(txtSID.Text);
            sp.CompanyName = txtCNAme.Text;
            sp.Address1 = txtAddress1.Text;
            sp.Address2 = txtAddress2.Text;
            sp.City = txtCity.Text;
            sp.State = cmbState.SelectedItem.ToString();
            sp.PostalCode = txtPincode.Text;
            sp.MobileNo = txtMobNo.Text;
            sp.EmailId = txtEmailID.Text;
            sp.Website = txtWeb.Text;
            isNumber = int.TryParse(txtRank.Text, out result);
            if (isNumber)
                sp.Ranking = result;
            else
            {
                MessageBox.Show("Enter Proper ranking from 1-5", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            sp.Note = txtNote.Text;
            sp.Password = txtPassword.Text;

            try
            {
                bool flag=cv.AddSupplier(sp);
                if (flag)
                {
                    MessageBox.Show("Supplier Added");
                    Admin ad = new Admin();
                    ad.Show();
                    this.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnViewProducts_Click(object sender, EventArgs e)
        {
            grdViewProducts.DataSource = cv.viewProduct();
        }

        private void btnViewSuppliers_Click(object sender, EventArgs e)
        {
            grdViewSuppliers.DataSource = cv.viewSupplier();
        }

        private void btnViewOrders_Click(object sender, EventArgs e)
        {
            grdViewOrders.DataSource = cv.viewOrder();
        }

        private void btnViewCustomers_Click(object sender, EventArgs e)
        {
            grdViewCustomers.DataSource = cv.viewCustomer();
        }

        private void txtCPassword_Leave(object sender, EventArgs e)
        {
            string pass = txtPassword.Text;
            string CnfrmPass = txtCPassword.Text;

            if (pass != CnfrmPass)
            {
                MessageBox.Show("Password MisMatched");
                txtPassword.Text = "";
                txtCPassword.Text = "";
                txtPassword.Focus();
            }


        }
    }
}
